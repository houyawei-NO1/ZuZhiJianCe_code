#ifndef __UTIL_H__
#define __UTIL_H__

DWORD reverse4(DWORD d);
WORD reverse2(WORD w);

#endif
