#ifndef _SOLVE_DIFFERENTIAL_EQUATION_H_
#define _SOLVE_DIFFERENTIAL_EQUATION_H_

#define uchar unsigned char
#define uint unsigned int

void solve_differential_equation();
 
#endif
