#ifndef _SOLVE_DEFINITE_INTERGRAL_H_
#define _SOLVE_DEFINITE_INTERGRAL_H_

#define uchar unsigned char
#define uint unsigned int

void solve_definite_intergral();
 
#endif
