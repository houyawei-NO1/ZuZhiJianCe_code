#ifndef _STATISTICS_H_
#define _STATISTICS_H_

#define uchar unsigned char
#define uint unsigned int


void sta_menu1();
	
	
#endif