#ifndef __CALCULUS_H
#define __CALCULUS_H

#include "middle.h"

void calculus_funcWR(u8 keynum);
void calculus_funcWRa(u8 keynum);
void calculus_funcWRb(u8 keynum);
void calculus_funcWRh(u8 keynum);
void calculus_funcWRy(u8 keynum);
void calculus_funcShow(u8 keynum);

#endif


