#ifndef __NOR_CAL_H
#define __NOR_CAL_H

#include "middle.h"


void normal_calculate(u8 keynum);
void complex_calculate(u8 keynum);
    
#endif



