#ifndef __MATRIX_H
#define __MATRIX_H 

#include "middle.h"

void Ranks_Set(u8 keynum);
void Ranks_Amend(u8 keynum);
void Ranks_Caculate(u8 keynum);

void Ranks_2_4Set(u8 keynum);

#endif


